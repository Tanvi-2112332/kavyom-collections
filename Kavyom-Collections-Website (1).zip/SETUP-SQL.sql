-- Kavyom Collections: run once in Supabase SQL Editor on the Mumbai project.
create table if not exists public.storefront_state (
  id integer primary key check (id = 1),
  store_data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.storefront_state enable row level security;
drop policy if exists "Public can view Kavyom storefront" on public.storefront_state;
drop policy if exists "Kavyom owner can manage storefront" on public.storefront_state;
create policy "Public can view Kavyom storefront" on public.storefront_state for select using (true);
create policy "Kavyom owner can manage storefront" on public.storefront_state for all to authenticated
using (lower(coalesce(auth.jwt() ->> 'email','')) = 'tanviyendhe72@gmail.com')
with check (lower(coalesce(auth.jwt() ->> 'email','')) = 'tanviyendhe72@gmail.com');
-- Storage bucket product-images should already exist and be PUBLIC for product photo display.
-- Keep its upload limit at 2 MB; this site compresses uploads to WebP before upload.
