// Paste your Supabase Project URL and anon/public key below. Never use the service_role key here.
window.KAVYOM_CONFIG = {
  url: 'PASTE_SUPABASE_PROJECT_URL_HERE',
  anonKey: 'PASTE_SUPABASE_ANON_KEY_HERE'
};
