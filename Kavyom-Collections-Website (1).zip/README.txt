KAVYOM COLLECTIONS WEBSITE

FILES
- index.html: storefront + owner dashboard (responsive, cream/gold theme)
- config.js: Supabase project connection settings (fill in before publishing)
- SETUP-SQL.sql: additive database table and access policies

IMPORTANT CURRENT STATE
The website design is converted from your supplied HTML. The six products currently inside the original file are SAMPLE placeholders with no product photos. Replace/delete them from the admin dashboard before the public launch.

ONE-TIME CONNECTION
1. Open config.js in a text editor.
2. In Supabase > Project Settings > API, copy the Project URL and anon/public key. Paste them into config.js. Do NOT use service_role/secret key.
3. In Supabase SQL Editor, run SETUP-SQL.sql once. It only creates the storefront_state table and policies; it does not delete your existing tables.
4. In Supabase Authentication > Users, create/confirm the owner account tanviyendhe72@gmail.com and set its password yourself. Never share the password with anyone.
5. Upload index.html and config.js to the GitHub repository root. Cloudflare Pages can deploy the repository with no build command and output directory /.

ADMIN
Open the published website and tap Admin login. Enter the owner email and your Supabase Auth password. Owner-only editing controls appear after successful login. Use Publish to save changes. Product photos are compressed to WebP and uploaded to the product-images bucket.

ORDERING
The original design includes cart and WhatsApp order-message generation. Set the WhatsApp number, UPI details and shipping fee in Settings. The current checkout is not a payment gateway: it does not collect online payments or automatically charge cards/UPI. For live payment collection, a payment provider integration and server-side order validation are still required.

SECURITY
Never put a Supabase service_role key in config.js. Only the anon/public key belongs in browser code. The admin identity is restricted to tanviyendhe72@gmail.com in both the page and database policy. Public visitors can read the storefront.
